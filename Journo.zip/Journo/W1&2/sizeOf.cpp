#include <iostream>
using namespace std;

int main() {
    int a;
    float b;
    double c;
    char d;
    string e;
    bool f;

  cout << sizeof a <</* " " , b, " " , c, " ",d," ",e ," ",f ,*/"\n";
  cout << sizeof b <<"\n";
  cout << sizeof c <<"\n";
  cout << sizeof d <<"\n";
  cout << sizeof e <<"\n";
  cout << sizeof f <<"\n";
  return 0;
}