#include<iostream>
using namespace std;

int main() 
{
 int a;

 cout<<"Enter number to find even or odd";
 cin>>a;

if (a%2==0)
{
    cout<<"The value is even"<<a;
}
else
{
    cout<<"The value is odd"<<a;
}




 return 0;
}