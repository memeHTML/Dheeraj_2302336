#include <iostream>
using namespace std;

int main() {
    int Sum=0, Avg=0, i, k[10];
    cout<<" Enter Ten Number with spaces ";
    for (i=0; i<10; i++){
        cin>>k[i];
        Sum+=k[i]; 
    };
        Avg=Sum/10;

    
    cout<<"Sum ="<<Sum<<endl;
    cout<<"Avg ="<<Avg<<endl;

    // cin >> n[0]>>n[1]>>n[2];

    // Sum = n[0] + n[1] + n[2];
    // Avg = (n[0] + n[1] + n[2])/3;

    // cout<< "Sum ="<<Sum<<endl;
    // cout<< "Avg ="<<Avg<<endl;

  return 0;

}