#include<iostream>
using namespace std;

int main()
{
    int n;

    cout<<"choose favourite umber betweeen 1-5";
    cin>>n;

    switch (n)
    {
    case 1:
        cout << "Number 1";
        break;

            case 2:
        cout << "Number 2";
        break;

            case 3:
        cout << "Number 3";
        break;

            case 4:
        cout << "Number 4";
        break;

            case 5:
        cout << "Number 5";
        break;
    }


}