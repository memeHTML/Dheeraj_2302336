#include<iostream>
using namespace std;
void neg(int val) {
    if (val<0){
        throw runtime_error("Error: Negative!");
    }
}

int main(){
    int num;

    cout<<"Enter a positive number: ";
    cin>> num;

    try {
        neg(num);
        cout<<"You Entered: "<<num<<endl;
    }
    catch(const runtime_error e) {
        cout<<e.what()<<endl;
    }

    return 0;
}