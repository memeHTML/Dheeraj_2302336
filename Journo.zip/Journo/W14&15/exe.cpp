#include <iostream>
using namespace std;

int main() {
    double numerator, denominator, result;

    cout<<"Enter Numerator: ";
    cin>>numerator;
    
    cout<<"Enter Denominator: ";
    cin>>denominator;

    try {
        if(denominator == 0) {
            throw runtime_error("Error: Division bu zero!");
        }
        result = numerator / denominator;
        cout<<"Result: "<<result<<endl;
    }catch(const runtime_error& e) {
        cout<<e.what()<<endl;
    }

    return 0;
}