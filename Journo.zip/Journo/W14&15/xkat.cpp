#include <iostream>
using namespace std;

int main() {
    double numerator, denominator;
    
    cout << "Enter numerator: ";
    cin >> numerator;
    
    cout << "Enter denominator: ";
    cin >> denominator;

    try {
        if (denominator == 0) {
            throw runtime_error("Error: Division by zero!"); // Throw for division by zero
        }
        
        if (numerator < 0) {
            throw invalid_argument("Error: Numerator cannot be negative!"); // Throw for negative numerator
        }

        double result = numerator / denominator; // Perform division
        cout << "Result: " << result << endl;
        
    } catch (const runtime_error& e) {
        cout << e.what() << endl; // Catch and display division by zero error
    } catch (const invalid_argument& e) {
        cout << e.what() << endl; // Catch and display negative numerator error
    } catch (...) {
        cout << "Unexpected error occurred!" << endl; // Catch any other exceptions
    }

    return 0;
}