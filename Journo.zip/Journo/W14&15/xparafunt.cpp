#include <iostream>
using namespace std;

template <typename T,typename U>
void zupp(T a,U b) {
    cout <<"Value 1: "<< a <<"Value 2: "<<b<<endl;

}

int main(){
    zupp(1, 1.7);
    zupp(true, "A");
    zupp("A", 1);
    zupp(3.14, "zupp");
    zupp(std::string("c++"), std::string("Templates"));

    return 0;
}