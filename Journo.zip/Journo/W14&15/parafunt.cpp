#include <iostream>
using namespace std;

template <typename T>
void zupp(T& a, T& b){
    T temp = a;
    a = b;
    b = temp;
}

int main() {
    int x = 10, y = 20;
    cout<<"x: "<<x<<" y: "<<y<<endl;
    zupp(x,y);
    cout<<"Zupp x: "<<x<<" y: "<<y<<endl;
    
    double p = 1.3, q = 1.7;
    cout<<"x: "<<x<<" y: "<<y<<endl;
    zupp(x,y);
    cout<<"Zupp x: "<<x<<" y: "<<y<<endl;

    return 0;
}