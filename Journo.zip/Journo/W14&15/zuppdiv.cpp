#include<iostream>
using namespace std;

int mani(){
    int numerator = 10, denominator = 20;
    int result = numerator / denominator;
    cout<<"Result: "<<result<<endl;

    return 0;
}