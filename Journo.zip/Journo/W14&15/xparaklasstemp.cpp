#include <iostream>
#include <string>

using namespace std;

template <typename T, typename U>
class Pair {
private:
    T first;
    U second;

public:
    Pair(const T& f, const U& s) : first(f), second(s) {}

    void display() {
        cout << "First: " << first << endl;
        cout << "Second: " << second << endl;
    }
};

int main() {
    Pair<int, double> intDouble(42, 3.14);
    intDouble.display();

    Pair<string, char> stringChar("Hello", 'A');
    stringChar.display();

    return 0;
}