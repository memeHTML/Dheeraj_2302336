#include<iostream>
using namespace std;

int area(int a, int b)
{
    return a*b;
}
float area(float a, float b)
{
    return a*b;
}

int main()
{
    int c,d;
    float e,f;
    

    cout<<"enter two int values and two float values for a and b="; cin>>c>>d>>e>>f;

    int num1=area(c,d);
    float num2=area(e,f);

    cout<<num1<<"\n"<<num2;
    
    return 0;
}
