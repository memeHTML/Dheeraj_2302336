#include<iostream>
using namespace std;

int main()
{
    int a,b,c;

    cout<<"Entervalues for A and B\n";
    cin>> a >> b ;

    c=a;
    a=b;
    b=c;

    cout<<"After Swapping\n";
    cout<<"A="<<a<<"\n"<<"B="<<b;


return 0;






}