#include<iostream>
#include<cmath>
using namespace std;

int main(){

    cout<<"Square root of 81 is:"<<sqrt(81)<<"\n";

    cout<<"Round 3.2 is:"<<round(3.2)<<"\n";

    cout<<"log of 2 is:"<<log(2)<<"\n";

    cout<<"max value between 3 & 7 is:"<<max(3,7)<<"\n";

    cout<<"min value between 3 & 7 is:"<<min(3,7)<<"\n";

    cout<<"Absolute value of 4.7 is:"<<abs(4.7)<<"\n";
    
    cout<<"ceil value between 2.3 is:"<<ceil(2.3)<<"\n";

    cout<<"ceil value between 2.3 is:"<<floor(2.3)<<"\n";

    cout<<"power of 2^7 is:"<<pow(2,7)<<"\n";



}