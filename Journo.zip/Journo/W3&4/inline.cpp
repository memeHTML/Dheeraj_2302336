#include <iostream>
using namespace std;

void myfuncton(){
    cout<<"Displaying simple message using inline function";
}

int main(){
    myfuncton();
    return 0;
}