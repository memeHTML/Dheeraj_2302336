#include <iostream>
using namespace std;

class Student{
    public:
    int number;

    Student(int a) : number(a){}

    Student operator++(){
        ++number;
        return *this;
    } 
};

int main(){
    Student s(10);

    ++s;

    cout<<"Number after Inkrement: " << s.number;
}