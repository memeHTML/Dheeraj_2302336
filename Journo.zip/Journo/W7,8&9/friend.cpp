#include <iostream>
using namespace std;

class Student{
    private:
    string n;
    int m1,m2,m3;
    public:
    Student(string name,int mark1,int mark2,int mark3){
        n=name;
        m1=mark1;
        m2=mark2;
        m3=mark3;
    }
    void display(){ cout<<"Student: "<<n<<endl;
        cout<<"Mark 1= "<<m1<<endl;
        cout<<"Mark 2= "<<m2<<endl;
        cout<<"Mark 3= "<<m3<<endl;
    }
    friend float Average(Student s);
};

float Average(Student s){
    return (s.m1+s.m2+s.m3)/3.0f;
}

int main(){
    Student M("Adam",1,2,3);
    M.display();
    cout<<"Average: "<<Average(M)<<endl;

    return 0;
}