#include <iostream>
using namespace std;

class Student{
    public:
    string name;
    double number;

    Student(string n = "Unknown" , int o = 0)
    {
        name = n;
        number = o;
    }

    void display() const {
        cout<<"Nmae: "<< name<< "\n" << "Number: "<< number << endl;
    }
};

int main(){
    Student s1,s2("Adam", 33);
    s1.display();
    s2.display();

    return 0;
}
