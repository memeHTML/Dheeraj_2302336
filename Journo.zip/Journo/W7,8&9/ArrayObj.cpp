#include <iostream>
using namespace std;

class Bike {
    private:

    string name;
    int year,price;

    public:
    void getdata();
    void putdata();
};

void Bike::getdata(){
    cout<<"Enter Bike Name: ";
    cin>>name;
    cout<<"Enter Year: ";
    cin>>year;
    cout<<"Enter Price: ";
    cin>>price;
}
void Bike::putdata(){
    cout<<"Bike Name: "<<name<<endl;
    cout<<"Bike Year: "<<year<<endl;
    cout<<"Bike Price: "<<price<<endl;
}
int main(){
    Bike Kawasaki[2];
    Bike Suzuki[2];

    for (int i=0;i<2; i++)
    {
        cout<<"For Kawasaki"<<endl;
        Kawasaki[i].getdata();
    }   
        cout<<endl;
        for (int i=0;i<2;i++)
        {
            cout<<"Kawasaki Data: "<<endl;
            Kawasaki[i].putdata();
        }

    for (int i=0;i<2; i++)
    {
        cout<<"For Suzuki"<<endl;
        Suzuki[i].getdata();
    }   
        cout<<endl;
        for (int i=0;i<2;i++)
        {
            cout<<"Suzuki Data: "<<endl;
            Suzuki[i].putdata();
        }


        return 0;
}