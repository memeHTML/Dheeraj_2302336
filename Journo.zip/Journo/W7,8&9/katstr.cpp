#include <iostream>
using namespace std;

class String{
    public:
    string str;

    String(const char *x) : str(x) {}

    String operator+(const String &y){
        return String((str + y.str).c_str());
    }

    void display(){
        cout<<str<<endl;
    }
};

int main(){
    String str1("Bomba ");
    String str2("klatt");

    String str3 = str1 + str2;
    
    str3.display();

    return 0;
}