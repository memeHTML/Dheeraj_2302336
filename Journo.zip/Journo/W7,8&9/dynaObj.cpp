#include <iostream>
using namespace std;

class Student{
    public:
    int number;

    Student (int n) : number(n) {}

    void display() {
        cout<<"Number: "<< number <<endl;
    }
};

int main(){
    Student *s = new Student(10);

    s->display();

    delete s;

    return 0;
}