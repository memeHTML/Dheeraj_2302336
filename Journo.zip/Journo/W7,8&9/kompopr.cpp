#include <iostream>
using namespace std;

class Number{
    public:
    double n;

    Number (double a) {
        n = a;    
    }

    bool operator<(const Number &b){
        return n < b.n;
    }
};

int main(){
    Number k1(1), k2(2);

    if (k1 < k2)
    {
        cout<<k2.n<<" is Greater"<<endl;
    } else {
        cout<<k1.n<<" is Greater"<<endl;
    }

    return 0;
}