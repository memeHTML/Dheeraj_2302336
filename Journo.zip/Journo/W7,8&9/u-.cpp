#include <iostream>
using namespace std;

class Student{
    public:
    int number;

    Student(int a) : number(a){}

    Student operator-(){
        return Student(-number);
    }
};

int main(){
    Student s(10);

    Student Neganum = -s ;

    cout << "Original Value: "<<s.number<<endl;
    cout << "NEGAtion: "<<Neganum.number<<endl;

    return 0;

}