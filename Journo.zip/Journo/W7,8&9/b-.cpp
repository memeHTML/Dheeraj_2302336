#include <iostream>
#include <cmath>
using namespace std;

class Komplex{ 
public:
double x, y;
Komplex (double xkord, double ykord) : x(xkord), y(ykord){}

double operator-(const Komplex &z){
    return sqrt(pow(x - z.x, 2) + pow (y - z.y, 2));
}
};

int main(){
    Komplex k1(1.1, 1.3), k2(1.7, 1.9);

    double distance = k2 - k1;
    cout<<"distance: "<<distance;

    return 0;
}