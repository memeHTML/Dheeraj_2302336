#include <iostream>
using namespace std;

class Komplex{
    public:
    float real, imag;

    Komplex(float x, float y) : real(x), imag(y) {}
    
    Komplex operator+(const Komplex &z) {
        return Komplex(real + z.real, imag + z.imag);
    }
};

int main(){
    Komplex k1(1.2, 1.3);
    Komplex k2(1.7, 1.9);

    Komplex k3 = k1 + k2;

    cout <<"Sum: "<<k2.real <<" ,"<<k3.imag<<"\n";

    return 0;
}