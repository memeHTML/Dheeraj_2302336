#include <iostream>
using namespace std;

class Student
{
public:
    int marks;

    Student (int m) : marks(m){
        
    }
};

int main(){
Student S(88);

int Student::*pointerMarks = &Student::marks;

S.*pointerMarks = 90;

cout<< "New Marks: " << S.marks << endl;

return 0;

}




















// class Student{
//     private:
//     string name;
//     int Mark1,Mark2;
//     public:
//     Student(string n, int m1,int m2){
//        name = n;
//        Mark1 = m1;
//        Mark2 = m2;
//     }
//     void display(){
//         cout<<"Name: "<<name<<"\n";
//         cout<<"Mark 1: "<<Mark1<<"\n";
//         cout<<"Mark 2: "<<Mark2<<"\n";
//     }

//     // int update(){ cout<<"Updating...\n";
//     //     cout<<"Enter name: ";
//     //     cin>>name;
//     //     cout<<"Enter Mark1: ";
//     //     cin>>Mark1;
//     //     cout<<"Enter Mark2:  ";        
//     //     cin>>Mark2;
//     // }
// };

// int main(){
//     Student student("Adam",1,2);
//     Student*ptr = &student;
//     student.display();
//     cout<<&*ptr;
//     Student teacher("Jose",7,9);
//     cout<<endl;
//     Student*dtr = &teacher;
//     *ptr=*dtr;
//     teacher.display();
//     cout<<&*ptr;

//     return 0;
// }