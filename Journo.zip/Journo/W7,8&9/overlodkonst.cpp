#include <iostream>
using namespace std;

class Rectangle {
private:
    double length;
    double width;

public:
    Rectangle() {
        length = 0.0;
        width = 0.0;
        cout << "Default constructor called" << endl;
    }

    Rectangle(double side) {
        length = side;
        width = side;
        cout << "Parameterized constructor (Square) called" << endl;
    }
    Rectangle(double l, double w) {
        length = l;
        width = w;
        cout << "Parameterized constructor (Rectangle) called" << endl;
    }

    Rectangle(const Rectangle &b) {
        length = b.length;
        width = b.width;
        cout << "kopy constructor (tangle) called" << endl;
    }

    double area() {
        return length * width;
    }
    
    void display()  {
        cout << "Length: " << length << ", Width: " << width << endl;
    }
};

int main() {
    Rectangle rect1;
    rect1.display();
    cout << "Area: " << rect1.area() << endl;

    cout << endl;

    Rectangle rect2(5.0);
    rect2.display();
    cout << "Area: " << rect2.area() << endl;

    cout << endl;
    
    Rectangle rect3(4.0, 6.0);
    rect3.display();
    cout << "Area: " << rect3.area() << endl;

    Rectangle rect4(rect2);
    rect4.display();
    cout << "Area: " << rect4.area() << endl;

    return 0;
}
