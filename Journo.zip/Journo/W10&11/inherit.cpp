#include <iostream>
using namespace std;

class Parent {
    public:
    void display(){
        cout<<"Parent class"<<endl;
    }
};
    class kid : public Parent {
        public:
        void show() {
            cout<< "kid class"<<endl;
        }
    };
int main() {
    kid k;
    k.display();
    k.show();
    return 0;
}