#include <iostream>
using namespace std;

class A{
    public: 
    void displayA(){
        cout<< "Klass A"<<endl;
    }
};

class B {
    public: 
    void displayB() {
        cout<<"Klass B"<<endl;
    }
};

class K : public A, public B{
    public:
    void display3() {
        displayA();
        displayB();
        cout<< "Derived Klass" <<endl;
    }
};

int main() {
    K k;
    k.display3();
    return 0;
}

