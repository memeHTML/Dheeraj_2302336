#include <iostream>
using namespace std;

class A{
    public:
    virtual void display(){
        cout<<"Base klass function"<<endl;
    }
};

class B final : public A{
    public: 
    void display() final{
        cout<<"Final klass function."<<endl;
    }
};

int main(){
    B b;
    b.display();
    return 0;
}