#include <iostream>
using namespace std;

class Shape {
    public: 
    virtual double area() = 0;
    virtual void draw() = 0;
};

class Square : public Shape {
    private:
    double side;

    public: 
    Square (double s) : side(s) {}

    double area() override {
        return side*side;
    }

    void draw() override {
        cout<<"Drawing a Square with side: "<<side<<endl;
    }
};

class Triangle : public Shape {
    private: 
    double height,base;

    public:
    Triangle(double b, double h) : height(h), base(b) {}

    double area() override {
        return (base*height)/2;
    }

    void draw() override {
        cout<< "Drawing a Tiangle with ""\n""height: "<<height<<" and base: "<<base<<endl;
    }
};

int main() {
    Shape* figure1 = new Square(3);
    Shape* figure2 = new Triangle(3, 7.77);

    figure1->draw();
    cout<< "Area : "<< figure1->area()<<endl;

    figure2->draw();
    cout<< "Area : "<< figure2->area()<<endl;

    delete figure1;
    delete figure2;
    return 0;
}