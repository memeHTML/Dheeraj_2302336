#include <iostream>
using namespace std;

class A{
    public:
    void DisplayA(){
        cout << "klass A"<<endl;
    }
};

class B : public A {
    public:
    void DisplayB(){
        cout<<"klass B"<< endl;
    }
};

class K : public B {
    public:
    void DisplayK(){
        cout << "Klass K"<<endl;
    }
};

int main() {
    K k;
    k.DisplayA();
    k.DisplayB();
    k.DisplayK();
    return 0;
}