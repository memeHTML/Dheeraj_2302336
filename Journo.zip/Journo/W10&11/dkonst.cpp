#include <iostream>
using namespace std;

class A {
public:
    A() {
        cout<<"Base Konstructor kalled"<<endl;
    }
    ~A() {
        cout<<"Base Destructor kalled"<<endl;
    };
};

class B : public A{
public:
    B() {
        cout<<"Derived Konstructor kalled"<<endl;
    }

    ~B() {
        cout<<"Derived Destructor kalled"<<endl;
    }
};

int main() {
    B b;
    return 0;
}