#include <iostream>
using namespace std;

class Parent {
    protected:
    int val;

    public:
    void newval(int v){
        val = v;
    }
};
    class Kid : public Parent{
        public:
        void yo() {
            cout<< "Protected Value: "<< val<< endl;
        }
    };

    int main(){
        Kid k;
        k.newval(1);
        k.yo();
        return 0;
    }
