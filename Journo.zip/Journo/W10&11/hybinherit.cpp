#include <iostream>
using namespace std;

class A{
    public:
    void display(){
        cout<<"Klass A"<<endl;
    }
};
class B : public A{
    public:
    void displayB(){
        cout<<"Klass B"<<endl;
    }
};
class K : public A{
    public:
    void displayK(){
        cout<<"Klass K"<<endl;
    }
};
class T: public B, public K{
    public:
    void displayT(){
        displayB();
        displayK();
        cout<<"Klass T"<<endl;
    }
};

int main() {
    T t;
    t.displayT();
    return 0;
}