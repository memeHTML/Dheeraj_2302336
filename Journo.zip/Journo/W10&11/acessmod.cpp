#include<iostream>
using namespace std;

class Parent{
    private:
    int val;

    public:
    void newval(int v) {
        val = v;
    }

    void display(){
        cout << "Private Value: "<< val <<endl;
    }
};

class Kid : public Parent{
    public: 
    void show() {
        cout << "Accessing Parent klass methods." <<endl;
        display();
    }
};

int main() {
    Kid k;
    k.newval(1);
    k.show();
    return 0;
}