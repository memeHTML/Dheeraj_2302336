#include <iostream>
using namespace std;

class A{
    public: 
    void DisplayA(){
        cout<<"klass A" <<endl;
    }
};

class B : public A{
    public:
    void DispalyB(){
        cout<<"Derived klass B"<<endl;
    }
};

class K : public A{
    public:
    void DisplayK(){
        cout << "Derived klass K"<<endl;
    }
};

int main(){
    B b;
    K k;

    b.DisplayA();
    b.DispalyB();

    k.DisplayA();
    k.DisplayK();

    return 0;
}