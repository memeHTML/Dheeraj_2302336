#include <iostream>
using namespace std;

class A {
    public: 
    void display(){
        cout<<"klass A"<<endl;
    }
};

class B : virtual public A{
    public:
    void displayB(){
        cout<<"Klass B"<<endl;
    }
};
class K : virtual public A{
    public:
    void displayK(){
        cout<<"Klass K"<<endl;
    }
};

class X : public B, public K{
    public:
    void displayX(){
        display();
        displayB();
        displayK();
        cout<<"Klass X"<<endl;
    }
};

int main(){
    X b;
    b.displayX();
    return 0;
}