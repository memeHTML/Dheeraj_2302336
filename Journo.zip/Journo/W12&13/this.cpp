#include <iostream>
using namespace std;

class A{
    private:
    int value;

    public:
    A(int a) : value(a) {}
    
    void display(){
        cout<<"Value: "<<this->value<<endl;
    }
};

int main() {
    A a(10);
    a.display();
    return 0;
}