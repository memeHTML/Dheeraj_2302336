#include <iostream>
using namespace std;

class A{
    public:
    void show(){
        cout<<"Base klass show function "<<endl;
    }
};

class B : public A{
    public: 
    void display(){
        cout<<"Base klass show function "<<endl;
    }
};

int main(){
    B b;
    A* ptr = &b;
    ptr->show();
    return 0;
}