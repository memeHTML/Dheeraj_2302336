#include <iostream>
using namespace std;

class A{
    public:
    void show(){
        cout<<"Base klass show function "<<endl;
    }
};

class B : public A{
    public: 
    void display(){
        cout<<"Derived klass show function "<<endl;
    }
};

int main(){
    A* ptr = new B;
    ptr->show();

    B* bptr = static_cast<B*>(ptr);
    bptr->display();
    delete ptr;
    return 0;
}