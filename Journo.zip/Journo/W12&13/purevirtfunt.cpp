#include <iostream>
using namespace std;

class A {
public:
   virtual void show() = 0;
};

class B : public A {
public:
   void show() override {
       cout << "ConcreteDerived implementation of show." << endl;
   }
};

int main() {
   A* ptr = new B();
   ptr->show();

   delete ptr;
   return 0;
}