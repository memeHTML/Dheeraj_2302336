#include <iostream>
using namespace std;

class A {
public:
    virtual void show() {
        cout << "Base class show function." << endl;
    }
};

class B : public A {
public:
    void show() override {
        cout << "Derived class show function." << endl;
    }
};

int main() {
    A* ptr = new B();

    ptr->show();

    delete ptr;
    return 0;
}
