#include <iostream>
using namespace std;

class A{
    public:
    void Display(){
        cout<<"Yo "<<endl;
    }
};

int main(){
    A a;
    A* ptr = &a;
    ptr->Display();
    return 0;
}