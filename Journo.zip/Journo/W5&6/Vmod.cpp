#include <iostream>
using namespace std;

class Student{
    public:
    string name;

    private:
    int age;

    public:
    Student (string n, int a){
    name = n;
    age = a;
    }

    void displayInfo() {
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl; 
    }

    void setAge(int a){
        age = a;
    }
    
    int getAge(){
        return age;
    }
};


int main(){
    Student student("Harry",10);

    cout<<"Student Name: "<<student.name<<endl;

    // cout<<"Age: "<<student.age<<endl;

    
    cout<<"Age: "<<student.getAge()<<endl;

    student.setAge(14);
    cout<<"Updated: "<<student.getAge();

    return 0;
}
