#include <iostream>
using namespace std;

class Person {
private:
    string name;
    static int count;

public:
    Person(string n) : name(n) {
    }

    ~Person() {
    }

    static int getCount() {
        return count;
    }

    void display() {
        cout << "Name: " << name << endl;
    }
};

int Person::count = 0;

int main() {
    cout << "Initial count: " << Person::getCount() << endl;  
    Person p1("John");
    Person p2("Alice");
    Person p3("Bob");

    cout << "Count after creating 3 instances: " << Person::getCount() << endl; 
    {
        Person p4("Eve");
        cout << "Count after creating another instance: " << Person::getCount() << endl;
    }

    cout << "Count after p4 is destroyed: " << Person::getCount() << endl; 

    return 0;
}
