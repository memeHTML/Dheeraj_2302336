#include<iostream>
using namespace std;

class abc{
public:
    int hello(){
    cout<<"Yo";
    }
};

int main(){
    abc a;
    a.hello();
        
return 0;
}