#include <iostream>
using namespace std;

class Counter{
    private:
    static int count;

    public:
    Counter(){
        count++;
    }

    static int getCount(){
        return count;
    }

    static void resetCount(){
        count = 0;
    }

};

int Counter::count = 0;

int main(){

    cout<<"Initial Count Value: "<<Counter::getCount()<<endl;

    Counter c1;
    Counter c2;

    cout<<"Initial Count Value: "<<Counter::getCount()<<endl;

    Counter::resetCount();

    cout<<"Initial Count Value: "<<Counter::getCount()<<endl;

    Counter c3;

    cout<<"Initial Count Value: "<<Counter::getCount()<<endl;

    return 0;    
}
