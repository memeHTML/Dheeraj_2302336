#include <iostream>
using namespace std;
class r{
    
    public:
    inline int add(int a, int b){
        return a+b;
    }
    inline int mul(int a, int b){
        return a*b;
    }
};
int main(){
    r rr;
    int sum = rr.add(3,3);
    int mull = rr.mul(3,3);
    cout<< "Sum= "<< sum;
    cout<< "mul= "<< mull;
}