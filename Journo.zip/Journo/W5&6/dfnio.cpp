#include <iostream>
using namespace std;

class fnctn{
    public:
    void display(){
        cout<<"Ayo\n";
    }
    void show();
};

void fnctn::show(){
    cout<<"Yo";
}

int main(){
    fnctn k;
    k.display();
    k.show();
}